package combate_de_RPG;

import java.util.Scanner;

public class SistemaDeCombate {
	
	private Personagem jogador1;
	private Personagem jogador2;
	
	private Dado dado;
	private CalcularDano calculadora;
	
	private Scanner scanner;
	
	public SistemaDeCombate(Personagem jogador1, Personagem jogador2) {
		this.jogador1 = jogador1;
		this.jogador2 = jogador2;
		this.dado = new Dado();
		this.calculadora = new CalcularDano();
		this.scanner = new Scanner(System.in);
	}
	
	public void iniciar() {
		
		Personagem atual;
		Personagem alvo;
		
		if(Math.random() < 0.5) {
			atual = jogador1;
			alvo = jogador2;
		}else {
			atual = jogador2;
			alvo = jogador1;
		}
		
		System.out.println("Quem começa: " + atual.getNome());
		
		while(jogador1.estaVivo() && jogador2.estaVivo()) {
			
			System.out.println("\nTurno de " + atual.getNome());
			System.out.println("1 - Atacar");
			System.out.println("2 - Defender");
			
			int opção = scanner.nextInt();
			
			if(opção == 1) {
				int valorDado = dado.rolar();
				
				System.out.println("Dado: " + valorDado);
				
				if(valorDado >= 4) {
					int dano = calculadora.calcular(atual, alvo);
					
					alvo.receberDano(dano);
					
					System.out.println(atual.getNome() + " causou " + dano + " de dano!");
					alvo.pararDefesa();
				}else {
					System.out.println("Ataque errou!");
				}
			}else if(opção == 2) {
				
				atual.defender();
				System.out.println(atual.getNome() + " está defendendo.");
			}
			
			System.out.println(alvo.getNome() + " possui " + alvo.getVida() + " de vida.");
			
			Personagem temp = atual;
			atual = alvo;
			alvo = temp;
		}
		mostrarVencedor();
	}

	public void mostrarVencedor() {
		if (jogador1.estaVivo()) {
			System.out.println("\nVencedor: " + jogador1.getNome());
		}else {
			System.out.println("\nVencedor: " + jogador2.getNome());
		}
	}
}
