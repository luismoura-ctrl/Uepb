package combate_de_RPG;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("=== RPG ===");
		
		System.out.println("Nome para o jogador 1: ");
		String nome1 = scanner.nextLine();
		
		Personagem jogador1 = criarPersonagem(scanner, nome1);
		
		System.out.println("Nome para o jogador 2: ");
		String nome2 = scanner.nextLine();
		
		Personagem jogador2 = criarPersonagem(scanner, nome2);
		
		SistemaDeCombate combate = new SistemaDeCombate(jogador1, jogador2);
		
		combate.iniciar();
	}
	
	public static Personagem criarPersonagem(Scanner scanner, String nome) {
		
		System.out.println("1 - Guerreiro");
		System.out.println("2 - Mago");
		
		int opção = scanner.nextInt();
		scanner.nextLine();
		
		if(opção == 1) {
			return new Guerreiro(nome);
		}
		
		return new Mago(nome);
	}
}