package combate_de_RPG;

public class Main {

	public static void main(String[] args) {
		
		Personagem jogador1 = new Guerreiro("Arthu");
		
		Personagem jogador2 = new Mago("Lancelot");
		
		SistemaDeCombate combate = new SistemaDeCombate(jogador1, jogador2);
		
		combate.iniciar();
	}
}