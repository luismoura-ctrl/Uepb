package combate_de_RPG;

public class AcaoAtaque implements Acao{
	
	private final Dado dado;
	private final CalcularDano calculadora;
	
	public AcaoAtaque() {
		this.dado = new Dado();
		this.calculadora = new CalcularDano();
	}
	
	@Override
	public void executar(Personagem atual, Personagem alvo) {
		
		int valorDado = dado.rolar();
		
		if(valorDado >= 4) {
			
			int dano = calculadora.calcular(atual, alvo);
			alvo.receberDano(dano);
		}
	}
}