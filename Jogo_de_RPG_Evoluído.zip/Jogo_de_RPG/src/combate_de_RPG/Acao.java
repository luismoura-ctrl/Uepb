package combate_de_RPG;

public interface Acao {
	public void executar(Personagem atual, Personagem alvo);
}