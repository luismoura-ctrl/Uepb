package combate_de_RPG;

public class Guerreiro extends Personagem {

    public Guerreiro(String nome) {
        super(nome, 40, 10, 4);
    }

	@Override
	public int calularAtaque() {
		return getForça();
	}
}