package combate_de_RPG;

import java.util.Scanner;

public class SistemaDeCombate {
	
	private Personagem atual;
	private Personagem alvo;
	private SortearTurno definirPrimeiroJogador;
	private Scanner scanner;
	
	public SistemaDeCombate(Personagem atual, Personagem alvo) {
		this.atual = atual;
		this.alvo = alvo;
		this.definirPrimeiroJogador = new SortearTurno();
		this.scanner = new Scanner(System.in);
	}
	
	public void iniciar() {
		
		Personagem [] jogadores = definirPrimeiroJogador.escolher(atual, alvo);
		
		atual = jogadores[0];
		alvo = jogadores[1];
		
		while(atual.estaVivo() && alvo.estaVivo()) {
			
			menuExibir();
			
			executarAcao(lerOpcao()); 
			
			mostrarStatus();
			
			trocarTurno();
		}
		mostrarVencedor();
	}

	public void mostrarVencedor() {
		if (atual.estaVivo()) {
			System.out.println("\nVencedor: " + atual.getNome());
		}else {
			System.out.println("\nVencedor: " + alvo.getNome());
		}
	}
	
	private void trocarTurno() {
		Personagem temp = atual;
		atual = alvo;
		alvo = temp;
	}

	private void menuExibir() {
		System.out.println("\nTurno de " + atual.getNome());
		System.out.println("1 - Atacar");
		System.out.println("2 - Defender");
	}
	
	private int lerOpcao() {
		return scanner.nextInt();
	}
	
	private void executarAcao(int opcao) {
		Acao acao;
		
		switch(opcao) {
		
		case 1:
			acao = new AcaoAtaque();
			acao.executar(atual, alvo);
			break;
			
		case 2:
			acao = new AcaoDefender();
			acao.executar(atual, alvo);
			break;
			
			default:
				System.out.println("Opção inválida.");
				break;
		}
	}
	
	private void mostrarStatus() {
		System.out.println(alvo.getNome() + " possui " + alvo.getVida() + " de vida.");
	}
}