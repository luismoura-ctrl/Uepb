package combate_de_RPG;

public class Mago extends Personagem {

    public Mago(String nome) {
        super(nome, 30, 14, 2);
    }

	@Override
	public int calularAtaque() {
		return getForça();
	}
}