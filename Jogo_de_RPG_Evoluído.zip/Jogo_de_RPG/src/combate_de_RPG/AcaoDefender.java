package combate_de_RPG;

public class AcaoDefender implements Acao{
	
	@Override
	public void executar(Personagem atual, Personagem alvo) {
		atual.defender();
	}
}