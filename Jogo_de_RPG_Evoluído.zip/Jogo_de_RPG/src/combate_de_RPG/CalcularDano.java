package combate_de_RPG;

public class CalcularDano {
	
	public int calcular(Personagem atacante, Personagem alvo) {
		
		int dano = atacante.calularAtaque() - alvo.getDefesa();
		
		if(dano < 1) {
			dano = 1;
		}
		
		return dano;
	}
}