package combate_de_RPG;

public abstract class Personagem {
	
	private String nome;
	private int vida;
	private int força;
	private int defesa;
	private boolean defendendo;
	
	public Personagem(String nome, int vida, int força, int defesa) {
		this.nome = nome;
		this.vida = vida;
		this.força = força;
		this.defesa = defesa;
	}
	
	public abstract int calularAtaque();
	
	
	public void receberDano(int dano) {
		vida -= dano;
		
		if(vida < 0) {
			vida = 0;
		}
	}
	
	public void defender() {
		defendendo = true;
	}
	
	public void pararDefesa() {
		defendendo = false;
	}
	
	public int getDefesa() {
		if(defendendo) {
			return defesa * 2;
		}
		
		return defesa;
	}
	
	public String getNome() {
		return nome;
	}
	
	public int getVida() {
		return vida;
	}
	
	public int getForça() {
		return força;
	}
	
	public boolean estaVivo() {
		return vida > 0;
	}
}