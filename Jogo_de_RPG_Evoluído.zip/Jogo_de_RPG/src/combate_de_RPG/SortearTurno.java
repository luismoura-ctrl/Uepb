package combate_de_RPG;

public class SortearTurno {
	
	public Personagem [] escolher(Personagem personagem1, Personagem personagem2) {
		if(Math.random() < 0.5) 
			
			return new Personagem [] {personagem1, personagem2};
			return new Personagem[] {personagem2, personagem1};
	
	}
}