package combate_de_RPG_test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import combate_de_RPG.Personagem;
import combate_de_RPG.Guerreiro;
import combate_de_RPG.Mago;

class SistemaDeCombateTest {

	@Test
	public void personagensDevemEstarVivosNoInício() {
		Personagem jogador1 = new Guerreiro("Arthur");
		Personagem jogador2 = new Mago("Merlin");
		assertTrue(jogador1.estaVivo());
		assertTrue(jogador2.estaVivo());
	}
	
	@Test
	public void escolherQuemVaiPrimeiro() {
		Personagem jogador1 = new Guerreiro("Arthur");
		Personagem jogador2 = new Mago("Merlin");
		if(Math.random() < 0.5) {
			assertEquals(jogador1, jogador1);
		}else {
			assertEquals(jogador2, jogador2);
		}
	}
}