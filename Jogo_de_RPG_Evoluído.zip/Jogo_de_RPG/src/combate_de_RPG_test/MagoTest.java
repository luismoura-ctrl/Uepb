package combate_de_RPG_test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import combate_de_RPG.Mago;

class MagoTest {

	@Test
	public void deveCriarMagoCorretamente() {
		Mago mago = new Mago("Merlin");
		assertEquals("Merlin", mago.getNome());
		assertEquals(30, mago.getVida());
		assertEquals(14, mago.getForça());		
	}
	
	@Test
	public void deveCalcularAtaqueDoMago() {
		Mago mago = new Mago("Merlin");
		assertEquals(14, mago.calularAtaque());	
	}
}