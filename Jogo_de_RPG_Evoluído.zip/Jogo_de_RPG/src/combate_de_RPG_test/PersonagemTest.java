package combate_de_RPG_test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import combate_de_RPG.Guerreiro;

class PersonagemTest {

	@Test
	public void deveReceberDano() {
		Guerreiro guerreiro = new Guerreiro("Arthut");
		guerreiro.receberDano(10);
		assertEquals(30, guerreiro.getVida());
	}
	
	@Test
	public void nãoDevePermitirVidaNegativa() {
		Guerreiro guerreiro = new Guerreiro("Arthut");
		guerreiro.receberDano(100);
		assertEquals(0, guerreiro.getVida());
	}
	
	@Test
	public void deveDobrarDefesa() {
		Guerreiro guerreiro = new Guerreiro("Arthut");
		guerreiro.defender();
		assertEquals(8, guerreiro.getDefesa());
	}
}