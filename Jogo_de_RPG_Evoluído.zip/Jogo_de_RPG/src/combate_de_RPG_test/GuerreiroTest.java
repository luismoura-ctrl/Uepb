package combate_de_RPG_test;

import combate_de_RPG.Guerreiro;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class GuerreiroTest {

	@Test
	public void deveCriarCorretamenteGuerreiro() {
		Guerreiro guerreiro = new Guerreiro("Arthur");
		assertEquals("Arthur", guerreiro.getNome());
		assertEquals(40, guerreiro.getVida());
		assertEquals(10, guerreiro.getForça());			
	}
	
	@Test
	public void deveCalcularAtaqueDoGuerreiro() {
		Guerreiro guerreiro = new Guerreiro("Arthur");
		assertEquals(10, guerreiro.calularAtaque());	
	}
}