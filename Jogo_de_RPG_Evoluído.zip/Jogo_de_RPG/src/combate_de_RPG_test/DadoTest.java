package combate_de_RPG_test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import combate_de_RPG.Dado;

class DadoTest {

	@Test
	public void deveGerarValorEntreUmESeis() {
		Dado dado = new Dado();
		
		for(int i = 0; i < 100; i++) {
			int valor = dado.rolar();
			assertTrue(valor >= 1);
			assertTrue(valor <= 6);
		}
	}
}