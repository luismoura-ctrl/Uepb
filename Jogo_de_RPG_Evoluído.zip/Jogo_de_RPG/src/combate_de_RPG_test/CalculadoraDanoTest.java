package combate_de_RPG_test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import combate_de_RPG.CalcularDano;
import combate_de_RPG.Guerreiro;
import combate_de_RPG.Mago;
import combate_de_RPG.Personagem;

class CalculadoraDanoTest {

	@Test
	public void deveCalcularDanoCorretamente() {
		Guerreiro guerreiro = new Guerreiro("Arthut");
		Mago mago = new Mago("Merlin");
		
		CalcularDano calculadora = new CalcularDano();
		int dano = calculadora.calcular(guerreiro, mago);
		
		assertEquals(8, dano);
	}
	
	@Test
	public void danoMinimoDeveSerUM() {
		
		CalcularDano calculadora = new CalcularDano();
		
		Personagem atacante = new Guerreiro("Arthur");
		Personagem alvo = new Mago("Merlin");
		alvo.defender();
		
		int dano = calculadora.calcular(atacante, alvo);
		assertTrue(dano >= 1);
	}
}